const express = require("express");
const mongoose = require("mongoose");

const app = express();
app.use(express.json());

// Env (coerenti con il tuo Deployment)
const PORT = process.env.PORT || 3000;
const MONGO_HOST = process.env.MONGO_HOST || "mongo";
const MONGO_PORT = process.env.MONGO_PORT || "27017";
const MONGO_DB = process.env.MONGO_DB || "helpdesk";
const MONGO_USER = process.env.MONGO_USER || "";
const MONGO_PASS = process.env.MONGO_PASS || "";

// Costruisce URI Mongo
function mongoUri() {
  // Se non hai auth, usa mongodb://host:port/db
  if (!MONGO_USER || !MONGO_PASS) {
    return `mongodb://${MONGO_HOST}:${MONGO_PORT}/${encodeURIComponent(MONGO_DB)}`;
  }
  // Con auth (authSource=admin come tipico per root user)
  return `mongodb://${encodeURIComponent(MONGO_USER)}:${encodeURIComponent(MONGO_PASS)}@${MONGO_HOST}:${MONGO_PORT}/${encodeURIComponent(MONGO_DB)}?authSource=admin`;
}

const TicketSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true, maxlength: 120 },
    description: { type: String, default: "", trim: true, maxlength: 2000 },
    priority: { type: String, enum: ["LOW", "MEDIUM", "HIGH"], default: "MEDIUM" },
    status: { type: String, enum: ["OPEN", "IN_PROGRESS", "CLOSED"], default: "OPEN" },
    createdBy: { type: String, default: "system", trim: true, maxlength: 80 }
  },
  { timestamps: true }
);

const Ticket = mongoose.model("Ticket", TicketSchema);

// Health / Ready (per probe K8s)
app.get("/healthz", (req, res) => res.status(200).send("ok"));

app.get("/readyz", (req, res) => {
  const state = mongoose.connection.readyState; // 0=disconnected,1=connected,2=connecting,3=disconnecting
  if (state === 1) return res.status(200).send("ready");
  return res.status(503).send("not-ready");
});

// Root info
app.get("/", (req, res) => {
  res.json({
    service: "ticketing-api",
    version: "1.0.0",
    endpoints: [
      "GET /tickets",
      "POST /tickets",
      "GET /tickets/:id",
      "PATCH /tickets/:id",
      "DELETE /tickets/:id"
    ]
  });
});

// CRUD Tickets

// Lista + filtri ?status=OPEN&priority=HIGH
app.get("/tickets", async (req, res) => {
  const q = {};
  if (req.query.status) q.status = req.query.status.toUpperCase();
  if (req.query.priority) q.priority = req.query.priority.toUpperCase();

  const tickets = await Ticket.find(q).sort({ createdAt: -1 }).limit(200);
  res.json(tickets);
});

// Crea ticket
app.post("/tickets", async (req, res) => {
  const { title, description, priority, createdBy } = req.body || {};
  if (!title || typeof title !== "string" || title.trim().length < 3) {
    return res.status(400).json({ error: "title is required (min 3 chars)" });
  }

  const doc = await Ticket.create({
    title: title.trim(),
    description: typeof description === "string" ? description.trim() : "",
    priority: priority ? String(priority).toUpperCase() : undefined,
    createdBy: createdBy ? String(createdBy).trim() : undefined
  });

  res.status(201).json(doc);
});

// Get singolo
app.get("/tickets/:id", async (req, res) => {
  const doc = await Ticket.findById(req.params.id);
  if (!doc) return res.status(404).json({ error: "not found" });
  res.json(doc);
});

// Update (status/priority/title/description)
app.patch("/tickets/:id", async (req, res) => {
  const patch = {};
  if (req.body.title !== undefined) patch.title = String(req.body.title).trim();
  if (req.body.description !== undefined) patch.description = String(req.body.description).trim();
  if (req.body.status !== undefined) patch.status = String(req.body.status).toUpperCase();
  if (req.body.priority !== undefined) patch.priority = String(req.body.priority).toUpperCase();

  const doc = await Ticket.findByIdAndUpdate(req.params.id, patch, {
    new: true,
    runValidators: true
  });

  if (!doc) return res.status(404).json({ error: "not found" });
  res.json(doc);
});

// Delete (opzionale, ma comodo)
app.delete("/tickets/:id", async (req, res) => {
  const doc = await Ticket.findByIdAndDelete(req.params.id);
  if (!doc) return res.status(404).json({ error: "not found" });
  res.json({ deleted: true });
});

// Avvio + connessione DB
async function start() {
  const uri = mongoUri();
  console.log("Connecting to MongoDB:", uri.replace(/:\/\/.*:.*@/, "://***:***@"));

  await mongoose.connect(uri, {
    serverSelectionTimeoutMS: 8000
  });

  app.listen(PORT, () => {
    console.log(`ticketing-api listening on :${PORT}`);
  });
}

start().catch((err) => {
  console.error("Startup error:", err);
  process.exit(1);
});

// Graceful shutdown
process.on("SIGTERM", async () => {
  try {
    await mongoose.disconnect();
  } finally {
    process.exit(0);
  }
});